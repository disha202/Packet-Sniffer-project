# packet-sniffer
This is a project in computer networks course for CSE students at faculty of engineering Ain-shams university.
This is a simple wireshark-like program used to capture packets and analyze them.
The project is developed using Java Jpcap library on netbeans IDE.
